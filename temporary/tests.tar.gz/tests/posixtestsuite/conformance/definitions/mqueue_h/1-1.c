/* 
   Test for the existance and valid format
   of the mq_attr structure as specified on 
   line 9678 of the Base Definitions document
*/

#include <mqueue.h>
#include "posixtest.h"
#include <stdio.h>

int main()
{
	fprintf(stderr, "Not Implemented!\n");
	return PTS_UNTESTED;
}
