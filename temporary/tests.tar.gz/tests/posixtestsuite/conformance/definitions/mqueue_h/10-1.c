/*
  Test for the existance and valid prototype
  of the mq_timedsend function as specified on
  line 9694 of the Base Definitions document
*/

#include <mqueue.h>
#include "posixtest.h"
#include <stdio.h>

int main()
{
	fprintf(stderr, "Test not implemented!\n");
        return PTS_UNTESTED;
}
