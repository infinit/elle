  /*
  Test that the POLL_OUT macro is defined.
  */

#include <signal.h>

#ifndef POLL_OUT
#error POLL_OUT not defined
#endif
