  /*
  Test that the ILL_COPROC macro is defined.
  */

#include <signal.h>

#ifndef ILL_COPROC
#error ILL_COPROC not defined
#endif
