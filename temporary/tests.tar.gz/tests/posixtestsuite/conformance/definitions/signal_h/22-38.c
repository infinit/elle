  /*
  Test that the SI_TIMER macro is defined.
  */

#include <signal.h>

#ifndef SI_TIMER
#error SI_TIMER not defined
#endif
