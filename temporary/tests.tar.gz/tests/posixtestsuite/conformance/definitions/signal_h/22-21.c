  /*
  Test that the BUS_OBJERR macro is defined.
  */

#include <signal.h>

#ifndef BUS_OBJERR
#error BUS_OBJERR not defined
#endif
