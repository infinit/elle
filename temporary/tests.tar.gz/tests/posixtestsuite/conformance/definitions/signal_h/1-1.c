  /*
  Test the existence of the signal.h file and that it can be
  included.
  */

#include <signal.h>
