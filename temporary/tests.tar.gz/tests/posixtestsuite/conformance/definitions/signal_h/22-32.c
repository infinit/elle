  /*
  Test that the POLL_MSG macro is defined.
  */

#include <signal.h>

#ifndef POLL_MSG
#error POLL_MSG not defined
#endif
