struct IconGenericPart  generic[128];
struct BitmapIconSpecificPart   specific[128];
unsigned short *bits[128];
struct font fonthead;
