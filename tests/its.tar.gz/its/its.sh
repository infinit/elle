#
# ---------- header -----------------------------------------------------------
#
# project       infinite
#
# license       FreeBSD
#
# file          /home/mycure/file-systems/tests/its/its.sh
#
# created       julien quintard   [thu oct 25 10:26:42 2007]
# updated       julien quintard   [fri oct 26 17:19:02 2007]
#
#! /bin/bash

#
# ---------- globals ----------------------------------------------------------
#

CWD=$(pwd)
DIRECTORY=$(dirname ${0})

TESTS="${CWD}/${DIRECTORY}/tests"

REPORT=""
DURATION=""
N=0
KO=0

#
# ---------- functions --------------------------------------------------------
#

#
# this function displays the usage.
#
its_usage()
{
  echo "[its::usage] ${0} [package] [test]"

  exit 1
}

#
# this function launches a test.
#
its_launch()
{
  package=${1}
  test=${2}

  # check that the test exists.
  if [ ! -f "${TESTS}/${package}/${test}.test" ] ; then
    return
  fi

  # get the current precise time.
  from=$(date "+%s.%N")

  # launch the test.
  output=$(bash "${TESTS}/${package}/${test}.test")

# XXX
#  echo "${output}"

  # get the current precise time.
  to=$(date "+%0s.%N")

  # compute the test duration.
  duration=$(echo "${to} - ${from}" | bc -l)

  # update the total time.
  if [ -z "${DURATION}" ] ; then
    DURATION="${duration}"
  else
    DURATION=$(echo "${DURATION} + ${duration}" | bc -l)
  fi

  # compute the number of operations and failed operations.
  n=$(echo "${output}" | grep -v "^$" | wc -l)
  ko=$(echo "${output}" | grep "\[ko\]" | wc -l)

  # update the total number of operations and failed ones.
  N=$(( ${N} + ${n} ))
  KO=$(( ${KO} + ${ko} ))

  # display the local results.
  echo -n "[${package}/${test}] in ${duration} seconds"

  if [ "${ko}" != "0" ] ; then
    echo "		${ko} failed on ${n} operations"

    errors=$(echo "${output}" | grep "\[ko\]" |
             grep "\[ko\]" | sed "s/\[ko\] //")

    if [ -n "${REPORT}" ] ; then
      REPORT="${REPORT}
"
    fi

    REPORT="${REPORT}[${package}/${test}]
${errors}"
  else
    echo ""
  fi
}

#
# this function triggers the tests from within a package.
#
its_trigger()
{
  package="${1}"

  # check if the package exists.
  if [ ! -d "${TESTS}/${package}" ] ; then
    return
  fi

  # retrieve the tests inside the package.
  tests=$(ls ${TESTS}/${package} | grep "^.*\.test$" |
          sed "s/^\(.*\)\.test$/\1/")

  # launch the tests.
  for test in ${tests} ; do
    its_launch ${package} ${test}
  done
}

#
# the main function.
#
its_main()
{
  packages=$(ls -d ${TESTS}/*/ | sed "s;${TESTS}/\(.*\)/;\1;")

  if [ ${#*} -eq 0 ] ; then
    for package in ${packages} ; do
      its_trigger ${package}
    done
  elif [ ${#*} -eq 1 ] ; then
    its_trigger ${1}
  elif [ ${#*} -eq 2 ] ; then
    its_launch ${1} ${2}
  else
    its_usage
  fi

  echo ""
  echo -n "[total] in ${DURATION} seconds			"
  echo "${KO} failed on ${N}"

  if [ -n "${REPORT}" ] ; then
    echo ""
    echo -n "---------- report -----------------------------------------"
    echo "---------------------"

    echo "${REPORT}"

    echo -n "-----------------------------------------------------------"
    echo "---------------------"
  fi
}

#
# ---------- entry point ------------------------------------------------------
#

its_main $*
